/*
 ZYNQ_USB_HOST, an example of integration of TinyUSB and enabling USB device mode 
 on Arty-Z7 (or any other Zynq7000 MPSoC from Xilinx) for Vivado 2017.3
 ==============================================================================

 This is the example's initialisation logic


 Designed in Magictale Electronics.
 
 Copyright (c) 2023 Dmitry Pakhomenko.
 dmitryp@magictale.com
 http://magictale.com
 
*/


#ifndef ZYNQ_USB_DEVICE_H
#define ZYNQ_USB_DEVICE_H

#include <FreeRTOS.h>
#include <task.h>
#include <xil_printf.h>
#include <xil_mmu.h>
#include "xuartps.h"
#include "xil_types.h"
#include "xparameters.h"
#include "xil_io.h"
#include "zynq_usb/tinyusb/tusb.h"
#include "zynq_usb/tinyusb/class/hid/hid.h"
#include "version.h"


#define DEFAULT_THREAD_PRIO 2
#define EXAMPLE_TIMEOUT_DEFAULT_US (5000000U)

static const uint32_t THREAD_STACKSIZE = 4096;

uint32_t example_main_thread(void);


#endif /* MDIO_OVER_GPIO_H */
