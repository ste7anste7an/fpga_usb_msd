/*
 ZYNQ_USB_HOST, an example of integration of TinyUSB and enabling USB HOST mode 
 on Arty-Z7 (or any other Zynq7000 MPSoC from Xilinx) for Vivado 2017.3
 ==============================================================================

 This is the example's initialisation logic


 Designed in Magictale Electronics.
 
 Copyright (c) 2023 Dmitry Pakhomenko.
 dmitryp@magictale.com
 http://magictale.com
 
*/

#include "zynq_usb_device.h"


#define UART_BASEADDR XPAR_PS7_UART_0_BASEADDR


uint32_t example_main_thread(void)
{
    /* This is the main thread responsible for hardware initialisation 
    */

    char version_string[VERSION_MAXIMUM_STRING_LENGTH];

    xil_printf("\r\n\r\n");
    xil_printf("----- USB device Mass Storage Device example ------\r\n");

    version_get_ps(version_string, sizeof(version_string));
    xil_printf("FW Version: %s\r\n", version_string);

    tusb_init();
    while (true)
    {
        tud_task();
    }

    vTaskDelete(NULL);
    return 0;
}

//--------------------------------------------------------------------+
// Device callbacks
//--------------------------------------------------------------------+

// Invoked when device is mounted
void tud_mount_cb(void)
{
    xil_printf("----- USB device mounted ------\r\n");
}

// Invoked when device is unmounted
void tud_umount_cb(void)
{
    xil_printf("----- USB device unmounted ------\r\n");
}

// Invoked when usb bus is suspended
// remote_wakeup_en : if host allow us  to perform remote wakeup
// Within 7ms, device must draw an average of current less than 2.5 mA from bus
void tud_suspend_cb(bool remote_wakeup_en)
{
    (void) remote_wakeup_en;
    xil_printf("S");
}

// Invoked when usb bus is resumed
void tud_resume_cb(void)
{
    xil_printf(".");
}

size_t board_get_unique_id(uint8_t id[], size_t max_len) {
  if ( max_len < 16 ) return 0;
  //uint32_t* id32 = (uint32_t*) (uintptr_t) id;
  //Chip_IAP_ReadUID(id32);
  // TODO: come up with some better Zynq identification - DmitryP
  return 16;
}

size_t board_usb_get_serial(uint16_t desc_str1[], size_t max_chars) {
  uint8_t uid[16] TU_ATTR_ALIGNED(4);
  size_t uid_len;

  if ( board_get_unique_id ) {
    uid_len = board_get_unique_id(uid, sizeof(uid));
  }else {
    // fixed serial string is 01234567889ABCDEF
    uint32_t* uid32 = (uint32_t*) (uintptr_t) uid;
    uid32[0] = 0x67452301;
    uid32[1] = 0xEFCDAB89;
    uid_len = 8;
  }

  if ( uid_len > max_chars / 2 ) uid_len = max_chars / 2;

  for ( size_t i = 0; i < uid_len; i++ ) {
    for ( size_t j = 0; j < 2; j++ ) {
      const char nibble_to_hex[16] = {
          '0', '1', '2', '3', '4', '5', '6', '7',
          '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
      };
      uint8_t const nibble = (uid[i] >> (j * 4)) & 0xf;
      desc_str1[i * 2 + (1 - j)] = nibble_to_hex[nibble]; // UTF-16-LE
    }
  }

  return 2 * uid_len;
}


