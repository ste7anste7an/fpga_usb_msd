//! @file version.h
//! @brief Reports software version
#ifndef VERSION_H
#define VERSION_H

#include <stdint.h>

#define VERSION_MAXIMUM_STRING_LENGTH 32

uint16_t version_get_major(void);

uint16_t version_get_minor(void);

uint16_t version_get_rev(void);

void version_get_ps(char * p_buffer, uint32_t length);

#endif
