/*
 ZYNQ_USB_DEVICE, an example of integration of TinyUSB and enabling USB DEVICE mode 
 on Arty-Z7 (or any other Zynq7000 MPSoC from Xilinx) for Vivado 2017.3
 ==============================================================================

 This is the top module of the example


 Designed in Magictale Electronics.
 
 Copyright (c) 2023 Dmitry Pakhomenko.
 dmitryp@magictale.com
 http://magictale.com
 
*/

#include "zynq_usb_device.h"

static StackType_t timer_task_stack_buf[configMINIMAL_STACK_SIZE];
static StackType_t idle_task_stack_buf[configMINIMAL_STACK_SIZE];
static StaticTask_t timer_task_tcb_buffer;
static StaticTask_t idle_task_tcb_buffer;

void vApplicationGetTimerTaskMemory( StaticTask_t **ppxTimerTaskTCBBuffer, StackType_t **ppxTimerTaskStackBuffer, uint32_t *pulTimerTaskStackSize )
{
    *ppxTimerTaskTCBBuffer = &timer_task_tcb_buffer;
    *ppxTimerTaskStackBuffer = timer_task_stack_buf;
    *pulTimerTaskStackSize = configMINIMAL_STACK_SIZE;
}

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
    *ppxIdleTaskTCBBuffer = &idle_task_tcb_buffer;
    *ppxIdleTaskStackBuffer = idle_task_stack_buf;
    *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
}


void send_Task()
{
while(1)
{
xil_printf("counter\r\n");
vTaskDelay(1000);
//taskYIELD();

}
}

int main(int argc, char ** argv)
{
    sys_thread_new("main_thread", (void (*)(void*)) example_main_thread, 0, THREAD_STACKSIZE, DEFAULT_THREAD_PRIO);
    sys_thread_new("send", (void (*)(void*)) send_Task, 0, THREAD_STACKSIZE, DEFAULT_THREAD_PRIO);

    vTaskStartScheduler();

    /* If all is well, the scheduler will now be running, and the following line
     will never be reached.  If the following line does execute, then the scheduler
     excited for some error condition */
    xil_printf("FreeRTOS scheduler error\r\n");

    for (;;)
        ;

    return 0;
}

